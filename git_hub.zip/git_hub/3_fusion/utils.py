import os
import numpy as np
import cv2
import imgaug.augmenters as iaa
import matplotlib.pyplot as plt
import torch as tc


def crop_image_from_gray(img, tol=7):
    if img.ndim == 2:
        mask = img > tol
        return img[np.ix_(mask.any(1), mask.any(0))]
    elif img.ndim == 3:
        gray_img = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
        mask = gray_img > tol

        check_shape = img[:, :, 0][np.ix_(mask.any(1), mask.any(0))].shape[0]
        if (check_shape == 0):  # image is too dark so that we crop out everything,
            return img  # return original image
        else:
            img1 = img[:, :, 0][np.ix_(mask.any(1), mask.any(0))]
            img2 = img[:, :, 1][np.ix_(mask.any(1), mask.any(0))]
            img3 = img[:, :, 2][np.ix_(mask.any(1), mask.any(0))]
            img = np.stack([img1, img2, img3], axis=-1)
        return img

def load_ben_color(image, sigmaX=30):
    image = cv2.resize(image, (512, 512))
    image = cv2.addWeighted (image,4, cv2.GaussianBlur( image , (0,0) , sigmaX) ,-4 ,128)
    #cv2.addWeighted() 图像融合。这里是把图像与高斯模糊后的图像做融合
    return image

def pretreatment(filepath):
    cv_img = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8), -1)
    #读取图像（可以是中文途径）
    img = cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB)
    #将BGR转化为RGB
    img=crop_image_from_gray(img)
    #自动剪裁
    img=load_ben_color(img)
    #高斯融合
    img=cv2.resize(img,(224,224))
    #最终剪裁
    return img

'''
将np转化为tensor
'''
def np2tensor(img):
    img=img.transpose((2,0,1))
    img=tc.from_numpy(img).type(tc.FloatTensor)
    img=img/255
    img = img.view(1, 3, 224, 224)
    return img

def cv_imread(filepath):
    cv_img = cv2.imdecode(np.fromfile(filepath, dtype=np.uint8), -1)
    return cv_img