import utils
import os
import numpy as np
import cv2
import matplotlib.pyplot as plt
import torch as tc
from torchvision import models

def vis(filename,savepath,classname,name):
    img=utils.cv_imread(filename)
    path0=os.path.join(savepath,classname)
    path = os.path.join(path0, name)

    img_origin = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_pretreatment = utils.pretreatment(filename)
    img_tc = utils.np2tensor(img_pretreatment)
    plt.figure()
    plt.subplot(421)
    plt.imshow(img_origin)
    plt.axis('off')

    plt.subplot(422)
    plt.imshow(img_pretreatment)
    plt.axis('off')

    '''
    加载网络
    '''
    vgg = models.vgg16(pretrained=False)
    num_ftrs = vgg.classifier[6].in_features
    vgg.classifier[6] = tc.nn.Linear(num_ftrs, 3)
    vgg.load_state_dict(tc.load('D:\\党\\大四下\\毕设程序\\毕设\\model\\vgg16.pth', map_location='cpu'))


    layer='1'
    if not os.path.exists(os.path.join(path,layer)):
        os.makedirs(os.path.join(path,layer))   #目录不存在时创建mnist目录创建origin目录
    path_name=os.path.join(path,layer)

    conv0=vgg.features[0](img_tc)
    relu1=vgg.features[1](conv0)
    num=relu1.shape[1]
    for i in range(num):
        img=relu1[0][i].detach().numpy()
        max_num=img.max()
        min_num=img.min()
        test=max_num-min_num
        if test==0:
            img=img
        else:
            img=(img-min_num)*255/(max_num-min_num)
        save_path=os.path.join(path_name,'{}.jpg'.format(i))
        cv2.imencode(save_path, img)[1].tofile(save_path)

    image = np.zeros((224, 224), dtype=np.float32)
    for i in range(num):
        image += relu1[0][i].detach().numpy()
    max_num = image.max()
    min_num = image.min()
    test = max_num - min_num
    if test == 0:
        image = image
    else:
        image = (image - min_num) * 255 / (max_num - min_num)
    save_path = os.path.join(path_name, 'main.jpg')
    cv2.imencode(save_path, image)[1].tofile(save_path)

    plt.subplot(423)
    plt.imshow(image, cmap='gray')
    plt.axis('off')

    image2=255-image
    save_path=os.path.join(path_name,'main2.jpg')
    cv2.imencode(save_path, image2)[1].tofile(save_path)

    plt.subplot(424)
    plt.imshow(image2, cmap='gray')
    plt.axis('off')


    layer='2'
    if not os.path.exists(os.path.join(path,layer)):
        os.makedirs(os.path.join(path,layer))   #目录不存在时创建mnist目录创建origin目录
    path_name=os.path.join(path,layer)

    conv2=vgg.features[2](relu1)
    relu3=vgg.features[3](conv2)
    maxpool4=vgg.features[4](relu3)
    num=maxpool4.shape[1]
    for i in range(num):
        img=maxpool4[0][i].detach().numpy()
        max_num=img.max()
        min_num=img.min()
        test=max_num-min_num
        if test==0:
            img=img
        else:
            img=(img-min_num)*255/(max_num-min_num)
        save_path=os.path.join(path_name,'{}.jpg'.format(i))
        cv2.imencode(save_path, img)[1].tofile(save_path)


    image=np.zeros((112,112),dtype= np.float32)
    for i in range(num):
        image+=maxpool4[0][i].detach().numpy()
    max_num=image.max()
    min_num=image.min()
    test=max_num-min_num
    if test==0:
        image=image
    else:
        image=(image-min_num)*255/(max_num-min_num)
    save_path=os.path.join(path_name,'main.jpg')
    cv2.imencode(save_path, image)[1].tofile(save_path)

    plt.subplot(425)
    plt.imshow(image, cmap='gray')
    plt.axis('off')

    image2=255-image
    save_path=os.path.join(path_name,'main2.jpg')
    cv2.imencode(save_path, image2)[1].tofile(save_path)
    plt.subplot(426)
    plt.imshow(image2,cmap='gray')
    plt.axis('off')

    layer='3'
    if not os.path.exists(os.path.join(path,layer)):
        os.makedirs(os.path.join(path,layer))   #目录不存在时创建mnist目录创建origin目录
    path_name=os.path.join(path,layer)

    conv5=vgg.features[5](maxpool4)
    relu6=vgg.features[6](conv5)
    num=relu6.shape[1]
    for i in range(num):
        img=relu6[0][i].detach().numpy()
        max_num=img.max()
        min_num=img.min()
        test=max_num-min_num
        if test==0:
            img=img
        else:
            img=(img-min_num)*255/(max_num-min_num)
        save_path=os.path.join(path_name,'{}.jpg'.format(i))
        cv2.imencode(save_path, img)[1].tofile(save_path)

    num=relu6.shape[1]
    image=np.zeros((112,112),dtype= np.float32)
    for i in range(num):
        image+=relu6[0][i].detach().numpy()
    max_num=image.max()
    min_num=image.min()
    test=max_num-min_num
    if test==0:
        image=image
    else:
        image=(image-min_num)*255/(max_num-min_num)
    save_path=os.path.join(path_name,'main.jpg')
    cv2.imencode(save_path, image)[1].tofile(save_path)
    plt.subplot(427)
    plt.imshow(image,cmap='gray')
    plt.axis('off')

    image2=255-image
    save_path=os.path.join(path_name,'main2.jpg')
    cv2.imencode(save_path, image2)[1].tofile(save_path)
    plt.subplot(428)
    plt.imshow(image2,cmap='gray')
    plt.axis('off')
    plt.show()

    layer='4'
    if not os.path.exists(os.path.join(path,layer)):
        os.makedirs(os.path.join(path,layer))   #目录不存在时创建mnist目录创建origin目录
    path_name=os.path.join(path,layer)

    conv7 = vgg.features[7](relu6)
    relu8 = vgg.features[8](conv7)
    maxpool9 = vgg.features[9](relu8)
    num = maxpool9.shape[1]
    for i in range(num):
        img = maxpool9[0][i].detach().numpy()
        max_num = img.max()
        min_num = img.min()
        test = max_num - min_num
        if test == 0:
            img = img
        else:
            img = (img - min_num) * 255 / (max_num - min_num)
        save_path = os.path.join(path_name, '{}.jpg'.format(i))
        cv2.imencode(save_path, img)[1].tofile(save_path)

    num = maxpool9.shape[1]
    image = np.zeros((56, 56), dtype=np.float32)
    for i in range(num):
        image += maxpool9[0][i].detach().numpy()
    max_num = image.max()
    min_num = image.min()
    test = max_num - min_num
    if test == 0:
        image = image
    else:
        image = (image - min_num) * 255 / (max_num - min_num)
    save_path = os.path.join(path_name, 'main.jpg')
    cv2.imencode(save_path, image)[1].tofile(save_path)

    image2 = 255 - image
    save_path = os.path.join(path_name, 'main2.jpg')
    cv2.imencode(save_path, image2)[1].tofile(save_path)
    plt.imshow(image2, cmap='gray')
    plt.axis('off')
    return 0




